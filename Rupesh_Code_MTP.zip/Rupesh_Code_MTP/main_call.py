from service import load_services
import time
from graph import build_graph
from stack import stack_based_all_paths
from service import *
from config import *
from multiprocessing import Process, Queue
import os


# ----------------------------------# Adding Dummy Nodes
start_service = Service(
    service_id="S",
    rake_num=None,
    start_station=None,
    start_time=None,
    end_station=None,
    end_time=None,
    direction=None,
    service_time=0
)

end_service = Service(
    service_id="T",
    rake_num=None,
    start_station=None,
    start_time=None,
    end_station=None,
    end_time=None,
    direction=None,
    service_time=0
)


def worker(worker_id,
           task_queue,
           G, start_service, end_service,
           DRIVING_TIME_LIMIT, DUTY_TIME_LIMIT,
           q):

    worker_start = time.time()
    local_count = 0

    output_csv = os.path.join(
        OUTPUT_DIR,
        f"{WORKER_FILE_PREFIX}{worker_id}.csv"
    )

    while True:
        try:
            service_id = task_queue.get_nowait()
        except:
            break

        count = stack_based_all_paths(
            G,
            start_service=start_service,
            end_service=end_service,
            DRIVING_TIME_LIMIT=DRIVING_TIME_LIMIT,
            DUTY_TIME_LIMIT=DUTY_TIME_LIMIT,
            max_paths=10000,
            output_csv=output_csv,
            allowed_first_services=[service_id]
        )

        local_count += count

    worker_end = time.time()
    elapsed = worker_end - worker_start

    q.put((worker_id, local_count, elapsed))


if __name__ == "__main__":

    total_start_time = time.time()

    # Ensure output directory exists
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    # ================================
    # Load services
    # ================================
    TIMETABLE_FILE = "C:/Users/srupe/Desktop/MTP/crew/mainLoop_aadesh.csv"
    services = load_services(TIMETABLE_FILE)

    # ================================
    # Build graph
    # ================================
    G = build_graph(services, start_service, end_service)

    # ================================
    # Dynamic Task Queue
    # ================================
    task_queue = Queue()
    all_services = sorted([s.service_id for s in services])

    for sid in all_services:
        task_queue.put(sid)

    # ================================
    # Create Workers
    # ================================
    num_workers = NUMBER_OF_CORES_TO_USE
    processes = []
    result_queue = Queue()

    parallel_start = time.time()

    for i in range(num_workers):
        p = Process(
            target=worker,
            args=(i + 1,
                  task_queue,
                  G, start_service, end_service,
                  DRIVING_TIME_LIMIT, DUTY_TIME_LIMIT,
                  result_queue)
        )
        processes.append(p)

    for p in processes:
        p.start()

    for p in processes:
        p.join()

    # ================================
    # Collect Results
    # ================================
    total_count = 0
    worker_times = {}

    for _ in processes:
        wid, count, elapsed = result_queue.get()
        total_count += count
        worker_times[wid] = elapsed

    parallel_end = time.time()

    print("\n--- Worker Execution Times ---")
    for wid in sorted(worker_times):
        print(f"Worker {wid}: {worker_times[wid]:.3f} seconds")

    print(f"\nTotal valid paths: {total_count}")
    print(f"Parallel wall time: {parallel_end - parallel_start:.3f} seconds")

    # ================================
    # Merge Worker CSVs
    # ================================
    final_output = os.path.join(OUTPUT_DIR, FINAL_OUTPUT_FILENAME)

    with open(final_output, "w", newline="") as outfile:
        for i in range(1, num_workers + 1):
            worker_file = os.path.join(
                OUTPUT_DIR,
                f"{WORKER_FILE_PREFIX}{i}.csv"
            )
            if os.path.exists(worker_file):
                with open(worker_file, "r") as infile:
                    for line in infile:
                        outfile.write(line)

    print(f"\nMerged all worker files into: {final_output}")

    total_end_time = time.time()
    print(f"[Total Time] {total_end_time - total_start_time:.3f} seconds")